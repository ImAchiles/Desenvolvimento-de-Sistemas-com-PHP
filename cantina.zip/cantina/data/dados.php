<?php
/**
 * Dados da Cantina Bella Italia
 * ------------------------------------------------------------------
 * Num projeto maior esses dados viriam de um banco (MySQL via PDO).
 * Aqui deixei em arrays para o app rodar sem precisar configurar banco,
 * mas a estrutura ja esta pronta pra voce trocar por consultas depois.
 */

function get_produtos(): array
{
    return [
        [
            'id'        => 1,
            'nome'      => 'Spaghetti alla Carbonara',
            'categoria' => 'Massas',
            'preco'     => 42.90,
            'descricao' => 'Receita romana classica: ovos, guanciale, pecorino e pimenta do reino. Sem creme de leite, do jeito tradicional.',
            'imagem'    => 'carbonara.jpg',
        ],
        [
            'id'        => 2,
            'nome'      => 'Lasagna alla Bolognese',
            'categoria' => 'Massas',
            'preco'     => 48.00,
            'descricao' => 'Camadas de massa fresca, molho bolonhesa cozido por horas, bechamel e muito parmesao gratinado.',
            'imagem'    => 'lasagna.jpg',
        ],
        [
            'id'        => 3,
            'nome'      => 'Pizza Margherita',
            'categoria' => 'Pizzas',
            'preco'     => 39.90,
            'descricao' => 'Massa de fermentacao natural, molho de tomate San Marzano, mussarela de bufala e manjericao fresco.',
            'imagem'    => 'margherita.jpg',
        ],
        [
            'id'        => 4,
            'nome'      => 'Risotto ai Funghi',
            'categoria' => 'Risotos',
            'preco'     => 45.50,
            'descricao' => 'Arroz arborio cremoso com mix de cogumelos, vinho branco e lascas de grana padano.',
            'imagem'    => 'risotto.jpg',
        ],
        [
            'id'        => 5,
            'nome'      => 'Tiramisu',
            'categoria' => 'Sobremesas',
            'preco'     => 24.00,
            'descricao' => 'Biscoito champagne embebido em cafe, creme de mascarpone e cacau. A sobremesa mais pedida da casa.',
            'imagem'    => 'tiramisu.jpg',
        ],
        [
            'id'        => 6,
            'nome'      => 'Antipasto Misto',
            'categoria' => 'Entradas',
            'preco'     => 36.00,
            'descricao' => 'Tabua de frios italianos, queijos, azeitonas, tomate seco e pao rustico quentinho.',
            'imagem'    => 'antipasto.jpg',
        ],
    ];
}

function get_servicos(): array
{
    return [
        [
            'icone' => "\u{1F37D}",
            'titulo' => 'Jantar no salao',
            'texto'  => 'Ambiente acolhedor com musica italiana ao vivo nas sextas e sabados. Reservas pelo telefone ou pelo site.',
        ],
        [
            'icone' => "\u{1F6F5}",
            'titulo' => 'Delivery proprio',
            'texto'  => 'Entregamos num raio de 8 km com embalagem termica. Pedido minimo de R$ 35,00.',
        ],
        [
            'icone' => "\u{1F389}",
            'titulo' => 'Eventos e festas',
            'texto'  => 'Buffet italiano para aniversarios, casamentos e confraternizacoes da empresa. Orcamento sob medida.',
        ],
        [
            'icone' => "\u{1F468}\u{200D}\u{1F373}",
            'titulo' => 'Aulas de culinaria',
            'texto'  => 'Workshops de massa fresca artesanal com o nosso chef. Turmas pequenas, todo mes.',
        ],
    ];
}
