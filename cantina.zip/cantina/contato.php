<?php
require __DIR__ . '/includes/header.php';

$enviado = false;
$erros = [];
$nome = $email = $mensagem = '';

// Trata o envio do formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome === '') {
        $erros[] = 'Conta pra gente seu nome.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'Coloque um e-mail valido pra gente te responder.';
    }
    if ($mensagem === '') {
        $erros[] = 'Escreva sua mensagem.';
    }

    if (empty($erros)) {
        // Aqui, num sistema real, voce salvaria no banco ou mandaria um e-mail.
        $enviado = true;
        $nome = $email = $mensagem = '';
    }
}
?>

<section class="bloco">
    <h2 class="titulo-secao">Fale com a gente</h2>
    <p class="sub-secao">Reserva, evento, pedido ou um simples oi. A gente responde rapidinho.</p>

    <?php if ($enviado): ?>
        <div class="aviso ok">Mensagem enviada! Logo a gente entra em contato. Grazie!</div>
    <?php endif; ?>

    <?php if ($erros): ?>
        <div class="aviso erro">
            <ul>
                <?php foreach ($erros as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" class="form" novalidate>
        <label>
            Nome
            <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>">
        </label>
        <label>
            E-mail
            <input type="email" name="email" value="<?= htmlspecialchars($email) ?>">
        </label>
        <label>
            Mensagem
            <textarea name="mensagem" rows="5"><?= htmlspecialchars($mensagem) ?></textarea>
        </label>
        <button type="submit" class="btn">Enviar mensagem</button>
    </form>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
