    </main>
    <footer class="rodape">
        <div class="container rodape-inner">
            <div>
                <h3>Cantina Bella Italia</h3>
                <p>Comida italiana de verdade desde 1998.</p>
            </div>
            <div>
                <h4>Onde estamos</h4>
                <p>Rua das Oliveiras, 120 - Centro</p>
                <p>Ter a Dom, das 18h as 23h</p>
            </div>
            <div>
                <h4>Fale com a gente</h4>
                <p>(11) 4000-1998</p>
                <p>contato@bellaitalia.com.br</p>
            </div>
        </div>
        <div class="rodape-base">
            &copy; <?= date('Y') ?> Cantina Bella Italia - Projeto academico (Desenvolvimento de Sistemas em PHP).
        </div>
    </footer>
</body>
</html>
