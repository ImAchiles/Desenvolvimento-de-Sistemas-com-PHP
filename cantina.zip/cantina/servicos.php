<?php
require __DIR__ . '/includes/header.php';
require __DIR__ . '/data/dados.php';
$servicos = get_servicos();
?>

<section class="bloco">
    <h2 class="titulo-secao">O que a gente oferece</h2>
    <p class="sub-secao">Mais do que comer bem, a Bella Italia quer te atender em cada ocasiao.</p>

    <div class="grade-servicos">
        <?php foreach ($servicos as $s): ?>
            <article class="servico">
                <div class="servico-ico"><?= $s['icone'] ?></div>
                <h3><?= htmlspecialchars($s['titulo']) ?></h3>
                <p><?= htmlspecialchars($s['texto']) ?></p>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<section class="faixa">
    <h2>Quer reservar uma mesa ou fechar um evento?</h2>
    <p>Chama a gente no telefone ou manda uma mensagem pela pagina de contato.</p>
    <a href="contato.php" class="btn">Falar com a cantina</a>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
