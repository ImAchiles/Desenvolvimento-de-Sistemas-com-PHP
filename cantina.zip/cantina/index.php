<?php require __DIR__ . '/includes/header.php'; ?>

<section class="hero">
    <div class="hero-texto">
        <h1>Um pedacinho da Italia<br>na sua mesa</h1>
        <p>Massas frescas, pizzas de forno e aquele tiramisu que todo mundo volta pra comer. Peca pelo site ou venha nos visitar.</p>
        <div class="hero-botoes">
            <a href="produtos.php" class="btn">Ver o cardapio</a>
            <a href="servicos.php" class="btn btn-vazado">Nossos servicos</a>
        </div>
    </div>
</section>

<?php
require __DIR__ . '/data/dados.php';
$destaques = array_slice(get_produtos(), 0, 3);
?>

<section class="bloco">
    <h2 class="titulo-secao">Os queridinhos da casa</h2>
    <p class="sub-secao">Tres pratos que quase nunca saem da lista de mais pedidos.</p>

    <div class="grade">
        <?php foreach ($destaques as $p): ?>
            <article class="card">
                <div class="card-img"><?= htmlspecialchars($p['nome']) ?></div>
                <div class="card-corpo">
                    <span class="tag"><?= htmlspecialchars($p['categoria']) ?></span>
                    <h3><?= htmlspecialchars($p['nome']) ?></h3>
                    <p><?= htmlspecialchars($p['descricao']) ?></p>
                    <div class="card-rodape">
                        <span class="preco">R$ <?= number_format($p['preco'], 2, ',', '.') ?></span>
                        <a href="carrinho.php?add=<?= $p['id'] ?>" class="btn btn-mini">Adicionar</a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
