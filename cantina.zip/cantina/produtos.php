<?php
require __DIR__ . '/includes/header.php';
require __DIR__ . '/data/dados.php';

$produtos = get_produtos();

// Filtro simples por categoria (vem pela URL, ex: produtos.php?cat=Massas)
$categorias = array_values(array_unique(array_column($produtos, 'categoria')));
$filtro = $_GET['cat'] ?? 'Todas';

if ($filtro !== 'Todas') {
    $produtos = array_filter($produtos, fn($p) => $p['categoria'] === $filtro);
}
?>

<section class="bloco">
    <h2 class="titulo-secao">Nosso cardapio</h2>
    <p class="sub-secao">Tudo feito na hora. Escolha uma categoria ou veja tudo de uma vez.</p>

    <div class="filtros">
        <a href="produtos.php?cat=Todas" class="chip <?= $filtro === 'Todas' ? 'ativo' : '' ?>">Todas</a>
        <?php foreach ($categorias as $c): ?>
            <a href="produtos.php?cat=<?= urlencode($c) ?>" class="chip <?= $filtro === $c ? 'ativo' : '' ?>"><?= htmlspecialchars($c) ?></a>
        <?php endforeach; ?>
    </div>

    <div class="grade">
        <?php foreach ($produtos as $p): ?>
            <article class="card">
                <div class="card-img"><?= htmlspecialchars($p['nome']) ?></div>
                <div class="card-corpo">
                    <span class="tag"><?= htmlspecialchars($p['categoria']) ?></span>
                    <h3><?= htmlspecialchars($p['nome']) ?></h3>
                    <p><?= htmlspecialchars($p['descricao']) ?></p>
                    <div class="card-rodape">
                        <span class="preco">R$ <?= number_format($p['preco'], 2, ',', '.') ?></span>
                        <a href="carrinho.php?add=<?= $p['id'] ?>" class="btn btn-mini">Adicionar</a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
