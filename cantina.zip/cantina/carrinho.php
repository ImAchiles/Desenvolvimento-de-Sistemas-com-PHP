<?php
require __DIR__ . '/includes/header.php';
require __DIR__ . '/data/dados.php';

$produtos = get_produtos();
// Indexa os produtos por id pra facilitar a busca
$por_id = [];
foreach ($produtos as $p) {
    $por_id[$p['id']] = $p;
}

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Adicionar item: carrinho.php?add=ID
if (isset($_GET['add'])) {
    $id = (int) $_GET['add'];
    if (isset($por_id[$id])) {
        $_SESSION['carrinho'][$id] = ($_SESSION['carrinho'][$id] ?? 0) + 1;
    }
    header('Location: carrinho.php');
    exit;
}

// Remover item: carrinho.php?remove=ID
if (isset($_GET['remove'])) {
    $id = (int) $_GET['remove'];
    unset($_SESSION['carrinho'][$id]);
    header('Location: carrinho.php');
    exit;
}

// Esvaziar tudo
if (isset($_GET['limpar'])) {
    $_SESSION['carrinho'] = [];
    header('Location: carrinho.php');
    exit;
}

$total = 0;
?>

<section class="bloco">
    <h2 class="titulo-secao">Seu pedido</h2>

    <?php if (empty($_SESSION['carrinho'])): ?>
        <div class="vazio">
            <p>Seu carrinho ainda esta vazio.</p>
            <a href="produtos.php" class="btn">Ir para o cardapio</a>
        </div>
    <?php else: ?>
        <table class="tabela">
            <thead>
                <tr>
                    <th>Prato</th>
                    <th>Preco</th>
                    <th>Qtd</th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['carrinho'] as $id => $qtd):
                    $p = $por_id[$id];
                    $subtotal = $p['preco'] * $qtd;
                    $total += $subtotal;
                ?>
                    <tr>
                        <td data-label="Prato"><?= htmlspecialchars($p['nome']) ?></td>
                        <td data-label="Preco">R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
                        <td data-label="Qtd"><?= $qtd ?></td>
                        <td data-label="Subtotal">R$ <?= number_format($subtotal, 2, ',', '.') ?></td>
                        <td data-label=""><a href="carrinho.php?remove=<?= $id ?>" class="remover">remover</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="total-label">Total</td>
                    <td colspan="2" class="total-valor">R$ <?= number_format($total, 2, ',', '.') ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="carrinho-acoes">
            <a href="carrinho.php?limpar=1" class="btn btn-vazado">Esvaziar carrinho</a>
            <a href="contato.php" class="btn">Finalizar pedido</a>
        </div>
    <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
