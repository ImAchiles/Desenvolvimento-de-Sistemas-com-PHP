<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Conta quantos itens tem no carrinho pra mostrar no menu
$qtd_carrinho = 0;
if (!empty($_SESSION['carrinho'])) {
    $qtd_carrinho = array_sum($_SESSION['carrinho']);
}

// Descobre qual pagina esta aberta pra marcar o menu
$pagina_atual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cantina Bella Italia</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="topo">
        <div class="container topo-inner">
            <a href="index.php" class="logo">
                <span class="logo-ico">🍅</span>
                Cantina <strong>Bella Italia</strong>
            </a>
            <nav class="menu">
                <a href="index.php" class="<?= $pagina_atual === 'index.php' ? 'ativo' : '' ?>">Inicio</a>
                <a href="produtos.php" class="<?= $pagina_atual === 'produtos.php' ? 'ativo' : '' ?>">Cardapio</a>
                <a href="servicos.php" class="<?= $pagina_atual === 'servicos.php' ? 'ativo' : '' ?>">Servicos</a>
                <a href="contato.php" class="<?= $pagina_atual === 'contato.php' ? 'ativo' : '' ?>">Contato</a>
                <a href="carrinho.php" class="btn-carrinho <?= $pagina_atual === 'carrinho.php' ? 'ativo' : '' ?>">
                    Carrinho<?php if ($qtd_carrinho > 0): ?> <span class="badge"><?= $qtd_carrinho ?></span><?php endif; ?>
                </a>
            </nav>
        </div>
    </header>
    <main class="container">
